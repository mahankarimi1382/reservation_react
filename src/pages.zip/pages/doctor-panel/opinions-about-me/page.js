import { CiSearch } from "react-icons/ci";
import DoctorProfIcon from "../../../../public/Pics/doctor-profile-icon.png";
import React from "react";
import Image from "next/image";
import { IoIosArrowDown } from "react-icons/io";
import DoctorPanelMenu from "@/container/doctor-panel/DoctorPanelMenu";
import AnswerOpinions from "@/container/doctor-panel/opinions-about-me/AnswerOpinions";

function page() {

  return (
    <div dir="rtl" className="flex pb-20  bg-[#F6FBFF]">
      <DoctorPanelMenu />
      <div className=" mt-10 w-full flex flex-col gap-7 items-center">
        <div className=" flex justify-between items-center w-[80%]">
          <label className=" bg-white w-[450px] border px-2 p-1 border-[#005DAD] rounded-xl flex justify-between ">
            <input className=" w-full outline-none" placeholder="جستجو" />
            <CiSearch className=" text-white text-4xl p-1 rounded-lg bg-[#005DAD]" />
          </label>
          <button className=" flex justify-center items-center p-2 border text-[#005DAD] gap-2 border-[#005DAD] rounded-xl">
            <Image src={DoctorProfIcon} width={24} alt="icon" />
            دکتر طاهر ثابتیان
            <IoIosArrowDown className=" text-xl" />
          </button>
        </div>
        <div className=" w-[80%] flex gap-7 flex-col">
          <AnswerOpinions />
        </div>
      </div>
    </div>
  );
}

export default page;
