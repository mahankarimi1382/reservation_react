"use client";
import Navbar from "@/components/Navbar";
import DashboardBox from "@/container/userPanel/dashboard/DashboardBox";
import HistorySummarySection from "@/container/userPanel/dashboard/HistorySummarySection";
import UserPanelMenue from "@/container/userPanel/UserPanelMenue";
import React from "react";
import historyIcon from "../../../../public/Pics/history-icon.png";
import RewardsSummarySection from "@/container/userPanel/dashboard/RewardsSummarySection";
import rewardsIcon from "../../../../public/Pics/UserPanel-Icons/rewards-icon.png";
import messageIcon from "../../../../public/Pics/UserPanel-Icons/message-icon.png";
import profile from "../../../../public/Pics/userPanelProfile.png";
import MessageSummarySection from "@/container/userPanel/dashboard/MessageSummarySection";
import opinnionsIcon from "../../../../public/Pics/UserPanel-Icons/opinions-icon.png";
import Image from "next/image";
import OpinnionsSummarySection from "@/container/userPanel/dashboard/OpinnionsSummarySection";
import WalletSummarySection from "@/container/userPanel/dashboard/WalletSummarySection";
import walletIcon from "../../../../public/Pics/UserPanel-Icons/wallet-icon.png";
import savedsIcon from "../../../../public/Pics/UserPanel-Icons/saves-icon.png";
import SavedsSummarySection from "@/container/userPanel/dashboard/SavedsSummarySection";
import { fullNameStorage } from "@/store/Store";
import { usePathname } from "next/navigation";
import dashboardIcon_blue from "../../../../public/Pics/UserPanel-Icons/dashboard-icon.png";
import acountInfoIcon_blue from "../../../../public/Pics/UserPanel-Icons/acountInfo-icon.png";
import historyIcon_blue from "../../../../public/Pics/UserPanel-Icons/history-icon.png";
import messageIcon_blue from "../../../../public/Pics/UserPanel-Icons/message-icon.png";
import rewardsIcon_blue from "../../../../public/Pics/UserPanel-Icons/rewards-icon.png";
import transactionsIcon_blue from "../../../../public/Pics/UserPanel-Icons/transaction-icon.png";
import walletIcon_blue from "../../../../public/Pics/UserPanel-Icons/wallet-icon.png";
import opinions_blue from "../../../../public/Pics/UserPanel-Icons/opinions-icon.png";
import saves_blue from "../../../../public/Pics/UserPanel-Icons/saves-icon.png";
import heart_blue from "../../../../public/Pics/UserPanel-Icons/heart-blue.png";
export const UserPanel_PhoneTitle = () => {
  let icon;
  let title;
  const pathName = usePathname();
  const handleTitleIcon = () => {
    switch (pathName) {
      case "/userPanel/dashboard":
        {
          title = "داشبورد";
          icon = dashboardIcon_blue;
        }
        break;
      case "/userPanel/acountInfo":
        {
          title = "اطلاعات حساب کاربری";
          icon = acountInfoIcon_blue;
        }
        break;
      case "/userPanel/history":
        {
          title = "سوابق";
          icon = historyIcon_blue;
        }
        break;
      case "/userPanel/messages":
        {
          title = "پیغام ها";
          icon = messageIcon_blue;
        }
        break;
      case "/userPanel/transactions":
        {
          title = "تراکنش ها";
          icon = transactionsIcon_blue;
        }
        break;
      case "/userPanel/wallet":
        {
          title = "کیف پول";
          icon = walletIcon_blue;
        }
        break;
      case "/userPanel/rewards":
        {
          title = "امتیاز ها";
          icon = rewardsIcon_blue;
        }
        break;
      case "/userPanel/opinions":
        {
          title = "نظرات";
          icon = opinions_blue;
        }
        break;
      case "/userPanel/saves":
        {
          title = "ذخیره شده ها";
          icon = saves_blue;
        }
        break;
      case "/userPanel/favorites":
        {
          title = "علاقه مندی";
          icon = heart_blue;
        }
        break;
      default:
        break;
    }
  };
  handleTitleIcon();

  return (
    <div className=" my-3 text-[#005DAD] flex items-center gap-1 lg:hidden w-[90%] mx-auto">
      <Image width={24} alt="icon" src={icon} />
      {title}
    </div>
  );
};
function page() {
  const { fullName } = fullNameStorage();

  return (
    <div dir="rtl" className=" pb-20 lg:pb-0 bg-[#F6FBFF] w-full">
      <Navbar />
      <UserPanel_PhoneTitle />
      <div className=" flex w-full">
        <UserPanelMenue />
        <div className=" lg:w-[82%] flex justify-center ">
          <div className=" gap-2 p-2 lg:p-0  bg-white w-[90%]  rounded-xl shadow-md flex flex-col lg:gap-4 xl:gap-10 lg:w-[97%] xl:w-[90%]">
            <div className=" flex lg:flex-row flex-col xl:gap-3 lg:gap-1 lg:p-2 xl:p-5 items-center">
              <Image src={profile} width={67} alt="profile" />
              <h2 className=" text-lg">
                {fullName == "string" ? "کاربر مهمان" : fullName} خوش آمدید
              </h2>
            </div>
            <div className=" gap-y-2 xl:-mt-10 flex lg:flex-row flex-wrap justify-between lg:px-2 xl:px-10">
              <DashboardBox title="سوابق" icon={historyIcon}>
                <HistorySummarySection />
              </DashboardBox>
              <DashboardBox is45 title="امتیاز ها" icon={rewardsIcon}>
                <RewardsSummarySection />
              </DashboardBox>
              <DashboardBox title="پیغام ها" icon={messageIcon}>
                <MessageSummarySection />
              </DashboardBox>
            </div>
            <div className=" flex justify-between gap-y-2 flex-wrap lg:px-2 xl:px-10">
              <DashboardBox Wfull title="نظرات" icon={opinnionsIcon}>
                <OpinnionsSummarySection />
              </DashboardBox>
              <DashboardBox Wfull title="کیف پول" icon={walletIcon}>
                <WalletSummarySection />
              </DashboardBox>

              <DashboardBox Wfull title="ذخیره شده ها" icon={savedsIcon}>
                <SavedsSummarySection />
              </DashboardBox>
            </div>{" "}
          </div>
        </div>
      </div>
    </div>
  );
}

export default page;
